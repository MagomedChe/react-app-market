import React from 'react';
import Button from "./Button";

function Card(props) {


    return (
        <div className="card">
            <div className="card-image">
                <img src={props.database.image} alt=""/>
            </div>
            <div className="card-info">
                <div className="card-name">{props.database.name} </div>
                <div className="rating">{props.database.rating} </div>
                <div className="card-price">{props.database.price} ₽</div>
                <Button setBought={props.setBought}/>
            </div>
        </div>
    );
}

export default Card;